#!/bin/fatpath/lua.elf

-- Play the templeOS theme song 'Risen' by Terry A. Davis
-- Source:  Sup1Hymns/TOSTheme.HC
--          Adam/ASnd.HC

sound = require("sound")

print("-- For my hero, Terry Davis --")

sound.play("5eDEqFFetEEFqDeCDDEetCGF")
sound.play("5eDEqFFetEEFqDeCDDEetCGF")
sound.play("5eDCqDE4eAA5etEEFEDG4B5DCqF")
sound.play("5eDCqDE4eAA5etEEFEDG4B5DCqF")
