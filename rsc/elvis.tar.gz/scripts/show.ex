"This script defines a :show alias, which illustrates the way that
"substitution works in an alias.

alias show echo !!<=!< !!%=!% !!?=!? !!*=!* !!^=!^ !!2=!2 !!$=!$ arg=!arg=
